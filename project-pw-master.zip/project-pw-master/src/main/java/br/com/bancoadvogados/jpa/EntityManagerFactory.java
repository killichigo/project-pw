/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.bancoadvogados.jpa;

/**
 *
 * @author Suporte Reposit
 */
class EntityManagerFactory {
    EntityManagerFactory factory = Persistence.createEntityManagerFactory("usuario");

EntityManager manager = factory.createEntityManager();

manager.close();
factory.close();

Usuario usuario = new Usuario();
usuario.setNome("Joaquin");
usuario.setEndereco("Rua 2 Aroreira");
tarefa.setDataFinalizacao(Calendar.getInstance());

EntityManagerFactory factory = Persistence.createEntityManagerFactory("tarefas");
EntityManager manager = factory.createEntityManager();

manager.getTransaction().begin();    
manager.persist(tarefa);
manager.getTransaction().commit();  

System.out.println("ID da tarefa: " + tarefa.getId());

manager.close();

}
