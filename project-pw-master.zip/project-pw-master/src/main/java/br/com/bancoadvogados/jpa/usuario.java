package br.com.bancoadvogados.jpa;



import java.util.Calendar;

/**
 *
 * @author Suporte Reposit
 */
@Entity
public class usuario {
    
    @Id
    private int rg;
    private int cpf;
    private String nome, endereco, email,senha;
    
   @Temporal(TemporalType.DATE)
    private Calendar dataNascimento;
   

    public void advogado(int rg, int cpf, String nome, String endereco, String email, String senha, Calendar dataNascimento) 
    {
    
        this.rg = rg;
        this.cpf = cpf;
        this.nome = nome;
        this.email = email;
        this.endereco = endereco;
        this.dataNascimento = dataNascimento;
        
        
    }

    public int getRG() 
    {
           return rg;
    }


    public void setRg(int rg) 
    {
            this.rg = rg;
    }


    public int getCpf() 
    {
           return cpf;
    }


    public void setCpf(int cpf) 
    {
            this.cpf = cpf;
    }
    
    public String getNome() 
    {
           return nome;
    }


    public void setNome(String nome) 
    {
            this.nome = nome;
    }
    
    public String getEndereco() 
    {
           return endereco;
    }


    public void setEndereco(String endereco) 
    {
            this.endereco = endereco;
    }
    
    public String getEmail() 
    {
           return email;
    }


    public void setEmail(String email) 
    {
            this.email = email;
    }
    
    public Calendar getDataNascimento() 
    {
           return dataNascimento;
    }


    public void setDataNascimento(Calendar DataNascimento) 
    {
            this.dataNascimento = dataNascimento;
    }









}
